package com.codegym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C07gSpringAopApplication {

    public static void main(String[] args) {
        SpringApplication.run(C07gSpringAopApplication.class, args);
    }

}
