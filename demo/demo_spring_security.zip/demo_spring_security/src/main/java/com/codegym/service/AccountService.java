package com.codegym.service;

import com.codegym.model.Account;

public interface AccountService {
    public void save(Account account);

}
